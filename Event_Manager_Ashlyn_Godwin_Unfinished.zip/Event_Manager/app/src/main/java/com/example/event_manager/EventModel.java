package com.example.event_manager;

public class EventModel {
    private String eventName;
    private String description;
    private String date;
    private int event_id;

    public EventModel(String eventName, String description, String date){
        this.eventName = eventName;
        this.description = description;
        this.date = date;
    }

    //Set/get

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return eventName +" / " + description;
    }

}
