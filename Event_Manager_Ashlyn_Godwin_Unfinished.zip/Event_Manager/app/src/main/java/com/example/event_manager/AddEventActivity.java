package com.example.event_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {

    EditText eventName_et, eventDesc_et, eventDate_et;
    Button addEvent_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        eventName_et = findViewById(R.id.eventName_et);
        eventDesc_et = findViewById(R.id.eventDesc_et);
        eventDate_et = findViewById(R.id.eventDate_et);
    }

    public void newEventOnClick(View view){
        //Add Event to DB
        EventModel eventModel;
        try{
            eventModel = new EventModel(eventName_et.getText().toString(), eventDesc_et.getText().toString(),eventDate_et.getText().toString());
        }
        catch (Exception e){
            eventModel = new EventModel("error", "error", "error");
        }
        DatabaseManager dbm= new DatabaseManager(this);
        boolean success = dbm.addEvent(eventModel);
        Toast.makeText(this, "success = " + success, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}