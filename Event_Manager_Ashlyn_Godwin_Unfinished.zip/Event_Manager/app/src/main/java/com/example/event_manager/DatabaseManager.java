package com.example.event_manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "movies.db";
    private static final int VERSION = 1;

    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class EventTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_EVENT_NAME = "event_name";
        private static final String COL_DATE = "date";
        private static final String COL_DESC = "description";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        //Usernames and Passwords (UserModel class)
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");

        //Event names, descriptions and dates (EventModel class)
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_EVENT_NAME + " text, " +
                EventTable.COL_DATE + " text, " +
                EventTable.COL_DESC + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE);
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public boolean addEvent(EventModel eventModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(EventTable.COL_EVENT_NAME, eventModel.getEventName());
        cv.put(EventTable.COL_DATE, eventModel.getDate());
        cv.put(EventTable.COL_DESC, eventModel.getDescription());
        long insert = db.insert(EventTable.TABLE, null, cv);
        if(insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public List<EventModel> getEvents(){
        List<EventModel> returnList = new ArrayList<>();

        String query = "SELECT * FROM " + EventTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){ //if results
            do {
                int eventID = cursor.getInt(0);
                String eventName = cursor.getString(1);
                String eventDescription = cursor.getString(2);
                String eventDate = cursor.getString(3);

                EventModel event = new EventModel(eventName,eventDescription, eventDate);
                returnList.add(event);
            }while(cursor.moveToFirst());
        }
        else {

        }
        cursor.close();
        db.close();
        return returnList;
    }

    public boolean addUser(UserModel UserModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(UserTable.COL_USERNAME, UserModel.getUsername());
        cv.put(UserTable.COL_PASSWORD, UserModel.getPassword());
        long insert = db.insert(UserTable.TABLE, null, cv);
        if(insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

}