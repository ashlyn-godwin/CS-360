package com.example.event_manager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Event_RecyclerViewAdapter extends RecyclerView.Adapter<Event_RecyclerViewAdapter.MyViewHolder> {

    Context context;
    List<EventModel> eventModelList;

    public Event_RecyclerViewAdapter(Context context, List<EventModel> eventModelList){
        this.context = context;
        this.eventModelList = eventModelList;
    }

    @NonNull
    @Override
    public Event_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.event_recycler_view_row, parent, false);
        return new Event_RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Event_RecyclerViewAdapter.MyViewHolder holder, int position) {
        //Assigning values to each row as they come on screen
        //based on position of recycler view
        holder.mEventName_tv.setText(eventModelList.get(position).getEventName());
        holder.mEventDesc_tv.setText(eventModelList.get(position).getDescription());
        holder.mEventDate_tv.setText(eventModelList.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        //how many items displayed for Recycler
        return eventModelList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView mEventName_tv, mEventDesc_tv, mEventDate_tv;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            mEventName_tv = itemView.findViewById(R.id.eventName_tv);
            mEventDate_tv = itemView.findViewById(R.id.eventDate_et);
            mEventDesc_tv = itemView.findViewById(R.id.eventDescription_tv);

        }
    }
}
