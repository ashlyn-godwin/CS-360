package com.example.event_manager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.CalendarView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton addFab;
    CalendarView cal;
    List<EventModel> eventModels = new ArrayList<>();
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.mRecyclerView);

        DatabaseManager dbm = new DatabaseManager(this);
        eventModels = dbm.getEvents(); //retrieve events

        Event_RecyclerViewAdapter adapter = new Event_RecyclerViewAdapter(this, eventModels);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void addEventOnClick(View view) {
        Intent intent = new Intent(this, AddEventActivity.class);
        startActivity(intent);
    }

}